import { Configuration } from "@activeviam/activeui-sdk";
import { devToolsEnhancerDevelopmentOnly } from "@redux-devtools/extension";
import { customStoreMiddleware } from "./customMiddleware";
import { applyMiddleware } from "redux";

export const registerStoreEnhancers = (configuration: Configuration) => {
  configuration.storeEnhancers = [
    ...(configuration.storeEnhancers || []),
    applyMiddleware(customStoreMiddleware),
    // VERY IMPORTANT !!!
    // If you put DEV_TOOLS stuff before custom enhancer/middleware,
    // you will receive unusual state/action objects because DEV_TOOLS will put wrapper around them.
    devToolsEnhancerDevelopmentOnly(),
  ];
};
