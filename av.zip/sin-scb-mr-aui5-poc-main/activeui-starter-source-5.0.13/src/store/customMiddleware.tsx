import { Middleware, Dispatch } from "redux";

import { Action as AUAction, State as AUState } from "@activeviam/activeui-sdk";
import { notifyMessage } from "../utils";
import { handlePageChanges } from "./handlePageChanges";
import { handleWidgetChanges } from "./handleWidgetChanges";

type ExtensionState = {
  customInfo: string;
};
type ExtensionAction = {
  type: "changeCustomInfo";
  payload: any;
};
type State = AUState & ExtensionState;
type Action = AUAction | ExtensionAction;

export const customStoreMiddleware: Middleware<{}, State, Dispatch<Action>> =
  (store) => (next: Dispatch<Action>) => (action: Action) => {
    /*
    NOTE: Ignore Undo/Redo actions
          - @@redux-undo/UNDO
          - @@redux-undo/REDO
    */
    if (action.type === "dashboardUpdated") {
      console.group(action.type);
      // The dashboard state slice supports undo/redo actions.
      // As a result, it has the following shape:
      // {
      //   future: [],
      //   past: [],
      //   present: {}, // the present property holds the current dashboard state.
      // };
      const currentDashboardState = store.getState().dashboard.present;
      const nextDashboardState = action.dashboardState;
      handlePageChanges(currentDashboardState, nextDashboardState);
      handleWidgetChanges(currentDashboardState, nextDashboardState);
      console.groupEnd();

      // If you want, you can even modify the dashboard state and replace the original one.
      const modifiedState = { ...action.dashboardState, __TEST__: "__TEST__" };
      return next({ ...action, dashboardState: modifiedState });
    } else if (action.type === "dashboardLoaded") {
      console.group(action.type);
      notifyMessage("Dashboard Loaded");
      console.groupEnd();
    } else if (action.type === "dashboardUnloaded") {
      console.group(action.type);
      notifyMessage("Dashboard Unloaded");
      console.groupEnd();
    }

    // Optional: You can dispatch your action here
    // store.dispatch({ type: "changeCustomInfo" });

    return next(action);
  };
