import {
  Cube,
  createFilter,
  Mdx,
  HierarchyCoordinates,
} from "@activeviam/activeui-sdk";
import { areHierarchiesEqual } from "./areHierarchiesEqual";

/**
 * For each filter in `addedFilters`:
 *   - if `existingMdxFilters` contains a "filter on members" on the same hierarchy, replaces it with the addedFilter.
 *   - otherwise adds the addedFilter at the end of the array.
 *
 * Mutates `existingMdxFilters`.
 */
export function addFilters({
  existingMdxFilters,
  addedFilters,
  cube,
}: {
  existingMdxFilters: Mdx[];
  addedFilters: [Mdx, HierarchyCoordinates][];
  cube: Cube;
}): void {
  const existingFilters = existingMdxFilters.map((existingMdxFilter) =>
    createFilter(existingMdxFilter, cube)
  );

  addedFilters.forEach((addedFilter) => {
    const [addedMdxFilter, hierarchy] = addedFilter;

    const indexOfFirstFilterOnMembers = existingFilters.findIndex(
      (existingFilter) => {
        return (
          existingFilter.type === "members" &&
          areHierarchiesEqual(hierarchy, existingFilter)
        );
      }
    );

    if (indexOfFirstFilterOnMembers !== -1) {
      existingMdxFilters[indexOfFirstFilterOnMembers] = addedMdxFilter;
    } else {
      existingMdxFilters.push(addedMdxFilter);
    }
  });
}
