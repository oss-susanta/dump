/** @jsx jsx */
import SubMenu from "antd/lib/menu/SubMenu";

import { jsx } from "@emotion/core";
import { FC } from "react";

interface CustomSubMenuProps {}

/**
 * Submenu containing menu items specific to user project.
 */
export const CustomSubMenu: FC<CustomSubMenuProps> = (props) => {
  return <SubMenu title="Custom" {...props} key="CustomSubMenu" />;
};
