import { HierarchyCoordinates } from "@activeviam/activeui-sdk";

/**
 * Returns whether `hierarchyCoordinatesA` and `hierarchyCoordinatesB` represent the same hierarchy.
 */
export function areHierarchiesEqual(
  hierarchyCoordinatesA: HierarchyCoordinates | undefined,
  hierarchyCoordinatesB: HierarchyCoordinates | undefined
): boolean {
  if (!hierarchyCoordinatesA || !hierarchyCoordinatesB) {
    return false;
  }

  return (
    hierarchyCoordinatesA.dimensionName ===
      hierarchyCoordinatesB.dimensionName &&
    hierarchyCoordinatesA.hierarchyName === hierarchyCoordinatesB.hierarchyName
  );
}
