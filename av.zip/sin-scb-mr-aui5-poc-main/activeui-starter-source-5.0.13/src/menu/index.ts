import { Configuration } from "@activeviam/activeui-sdk";
import { CustomSubMenu } from "./CustomSubMenu";
import { FilterByUSDMenuItem } from "./FilterByUSDMenuItem";

export const registerApplicationMenu = (configuration: Configuration) => {
  configuration.leftApplicationMenu = [
    ...configuration.leftApplicationMenu,
    {
      component: CustomSubMenu,
      children: [
        {
          component: FilterByUSDMenuItem,
        },
      ],
    },
  ];
};
