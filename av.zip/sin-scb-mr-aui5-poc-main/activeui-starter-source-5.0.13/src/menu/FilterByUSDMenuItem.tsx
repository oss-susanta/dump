/** @jsx jsx */
import MenuItem, {
  MenuItemProps as AntMenuItemProps,
} from "antd/lib/menu/MenuItem";

import { jsx } from "@emotion/core";
import { FC } from "react";
import { DollarCircleOutlined } from "@ant-design/icons";
import { useDispatch, useSelector } from "react-redux";
import {
  DashboardState,
  FilterOnMembers,
  getDashboardState,
  parse,
  isWidgetWithQueryState,
  useDataModels,
  getCubeName,
  getTargetCube,
  DataModel,
  DashboardUpdatedAction,
  createMdxForFilter,
  Mdx,
  createFilter,
  Cube,
  HierarchyCoordinates,
  getCube,
  DashboardPageState,
} from "@activeviam/activeui-sdk";
import { addFilters } from "./addFilters";
import { produce } from "immer";

type FilterByUSDMenuItemProps = AntMenuItemProps;

/**
 * Menu item to apply USD filter to the widgets.
 */
export const FilterByUSDMenuItem: FC<FilterByUSDMenuItemProps> = (props) => {
  // https://activeui.activeviam.com/activeui/documentation/latest/docs/api/functions/#getdashboardstate
  const dashboardState = useSelector(getDashboardState);

  // https://activeui.activeviam.com/activeui/documentation/latest/docs/api/hooks/#usedatamodels
  const dataModels = useDataModels();

  const dispatch = useDispatch();

  if (!dashboardState) {
    return null;
  }

  const applyFilter = () => {
    // Get the cube for currency filter
    // https://activeui.activeviam.com/activeui/documentation/latest/docs/api/functions/#getcube
    const serverKey = Object.keys(window.env.activePivotServers)[0];
    const cube = getCube(dataModels[serverKey], "EquityDerivativesCube");

    // Create currency USD filter and it's hierarchy to check if there is any existing currency filter
    const addedFilters = [_createMdxFilter(cube)];

    // Apply filter to dashboard state
    const updatedDashboardState = _getFilteredDashboardState(
      dashboardState,
      addedFilters,
      cube
    );

    // Update the dashboard
    // https://activeui.activeviam.com/activeui/documentation/latest/docs/api/types/#dashboardupdatedaction
    const action: DashboardUpdatedAction = {
      type: "dashboardUpdated",
      dashboardState: updatedDashboardState,
    };
    dispatch(action);
  };

  const handleClicked: AntMenuItemProps["onClick"] = async (param) => {
    // Closes the context menu item.
    if (props.onClick) {
      props.onClick(param);
    }
    applyFilter();
  };

  return (
    <MenuItem {...props} onClick={handleClicked}>
      <DollarCircleOutlined />
      Filter by USD
    </MenuItem>
  );
};

/**
 * Create USD filter
 * @param cube
 * @returns Mdx filter
 */
function _createMdxFilter(cube: Cube): [Mdx, HierarchyCoordinates] {
  const hierarchy: HierarchyCoordinates = {
    dimensionName: "Currency",
    hierarchyName: "Currency",
  };

  // https://activeui.activeviam.com/activeui/documentation/latest/docs/api/functions#createfilter
  const filter = createFilter(
    parse("[Currency].[Currency].[AllMember].[USD]"),
    cube
  );

  //https://activeui.activeviam.com/activeui/documentation/latest/docs/api/functions#createmdxforfilter
  const mdxFilter = createMdxForFilter(filter, cube);
  return [mdxFilter, hierarchy];
}

function _getFilteredDashboardState(
  dashboardState: DashboardState,
  addedFilters: [Mdx, HierarchyCoordinates][],
  cube: Cube,
  scope: "pages" | "widgets" = "widgets"
): DashboardState {
  return produce(dashboardState, (draft) => {
    // loop through each page in dashboard
    Object.keys(draft.pages).forEach((pageKey) => {
      const pageState = draft.pages[pageKey];
      if (scope === "pages") {
        _addPageFilters({ pageState, addedFilters, cube });
      } else if (scope === "widgets") {
        _addWidgetFilters({ pageState, addedFilters, cube });
      } else {
        console.error(`Invalid parameter scope: ${scope}`);
      }
    });
  });
}

function _addPageFilters({
  pageState,
  addedFilters,
  cube,
}: {
  pageState: DashboardPageState;
  addedFilters: [Mdx, HierarchyCoordinates][];
  cube: Cube;
}) {
  if (!pageState.filters) {
    pageState.filters = [];
  }
  addFilters({
    existingMdxFilters: pageState.filters,
    addedFilters,
    cube,
  });
}

function _addWidgetFilters({
  pageState,
  addedFilters,
  cube,
}: {
  pageState: DashboardPageState;
  addedFilters: [Mdx, HierarchyCoordinates][];
  cube: Cube;
}) {
  // loop through each widget in a page
  Object.keys(pageState.content).forEach((leafKey) => {
    const widgetState = pageState.content[leafKey];
    //https://activeui.activeviam.com/activeui/documentation/latest/docs/api/functions/#iswidgetwithquerystate
    if (isWidgetWithQueryState(widgetState)) {
      if (!widgetState.filters) {
        widgetState.filters = [];
      }
      addFilters({
        existingMdxFilters: widgetState.filters,
        addedFilters,
        cube,
      });
    }
  });
}
