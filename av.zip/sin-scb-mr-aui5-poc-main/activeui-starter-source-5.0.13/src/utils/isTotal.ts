import { Hierarchy, Member, MemberCoordinates } from "@activeviam/activeui-sdk";

/**
 * Given a hierarchy and member determines whether the member is a total.
 */
export const isTotal = (
  hierarchy: Hierarchy,
  member: MemberCoordinates | Member
): boolean => !hierarchy.slicing && member.namePath.length === 1;
