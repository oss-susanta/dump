import {
  Filter,
  FilterOnLowerOrGreaterCaptions,
} from "@activeviam/activeui-sdk";

/**
 * Returns whether `filter` is a {@link FilterOnLowerOrGreaterCaptions}.
 */
export function isFilterOnLowerOrGreaterCaptions(
  filter: Filter
): filter is FilterOnLowerOrGreaterCaptions {
  return filter.type === "lowerOrGreaterCaptions";
}
