import { Filter, FilterOnCaptionContaining } from "@activeviam/activeui-sdk";

/**
 * Returns whether `filter` is a {@link FilterOnCaptionContaining}.
 */
export function isFilterOnCaptionContaining(
  filter: Filter
): filter is FilterOnCaptionContaining {
  return filter.type === "captionsContaining";
}
