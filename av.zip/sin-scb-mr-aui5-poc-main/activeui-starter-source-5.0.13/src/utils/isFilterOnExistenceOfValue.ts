import { Filter, FilterOnExistenceOfValue } from "@activeviam/activeui-sdk";

/**
 * Returns whether `filter` is a {@link FilterOnExistenceOfValue}.
 */
export function isFilterOnExistenceOfValue(
  filter: Filter
): filter is FilterOnExistenceOfValue {
  return filter.type === "existenceOfValue";
}
