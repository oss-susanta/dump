import { Filter, FilterOnLowerOrGreaterValues } from "@activeviam/activeui-sdk";

/**
 * Returns whether `filter` is a {@link FilterOnLowerOrGreaterValues}.
 */
export function isFilterOnLowerOrGreaterValues(
  filter: Filter
): filter is FilterOnLowerOrGreaterValues {
  return filter.type === "lowerOrGreaterValue";
}
