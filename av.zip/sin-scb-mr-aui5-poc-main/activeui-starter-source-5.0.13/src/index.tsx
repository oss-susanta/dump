import {
  ExtensionModule,
  pluginWidgetPivotTable,
} from "@activeviam/activeui-sdk";
import { withSandboxClients } from "@activeviam/sandbox-clients";
import _merge from "lodash/merge";
import { applyMiddleware } from "redux";

import { plugins } from "./plugins";
import { devToolsEnhancerDevelopmentOnly } from "@redux-devtools/extension";
import { customStoreMiddleware } from "./store/customMiddleware";
import { CustomSubMenu } from "./menu/CustomSubMenu";
import { FilterByUSDMenuItem } from "./menu/FilterByUSDMenuItem";

const extension: ExtensionModule = {
  activate: async (configuration) => {
    _merge(configuration.pluginRegistry, plugins);
    configuration.applicationName = "ActiveUI";
    configuration.initialDashboardPageState = {
      content: { "0": pluginWidgetPivotTable.initialState },
      layout: {
        children: [
          {
            leafKey: "0",
            size: 1,
          },
        ],
        direction: "row",
      },
    };
    configuration.higherOrderComponents = [withSandboxClients];
    configuration.leftApplicationMenu = [
      ...configuration.leftApplicationMenu,
      {
        component: CustomSubMenu,
        children: [
          {
            component: FilterByUSDMenuItem,
          },
        ],
      },
    ];
    configuration.storeEnhancers = [
      ...(configuration.storeEnhancers || []),
      applyMiddleware(customStoreMiddleware),
      // VERY IMPORTANT !!!
      // If you put DEV_TOOLS stuff before custom enhancer/middleware,
      // you will receive unusual state/action objects because DEV_TOOLS will put wrapper around them.
      devToolsEnhancerDevelopmentOnly(),
    ];
  },
};

export default extension;
