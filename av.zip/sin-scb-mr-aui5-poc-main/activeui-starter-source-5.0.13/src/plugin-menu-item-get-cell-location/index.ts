export { pluginMenuItemGetCellLocation as pluginMenuItemGetCoordinates } from "./pluginMenuItemGetCellLocation";
