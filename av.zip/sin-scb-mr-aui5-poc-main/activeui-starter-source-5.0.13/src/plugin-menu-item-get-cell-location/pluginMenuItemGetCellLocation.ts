import { GetCellLocationMenuItem } from "./GetCellLocationMenuItem";
import {
  CellSetSelection,
  DataVisualizationWidgetState,
  MenuItemPlugin,
} from "@activeviam/activeui-sdk";

export const pluginKey = "get-cell-location";

/**
 * {@link MenuItemPlugin} allowing to get the current cell location.
 */
export const pluginMenuItemGetCellLocation: MenuItemPlugin<
  DataVisualizationWidgetState,
  CellSetSelection
> = {
  Component: GetCellLocationMenuItem,
  key: pluginKey,
  translations: {
    "en-US": {
      getCellLocation: "Get cell location",
    },
  },
};
