/** @jsx jsx */
import { jsx } from "@emotion/core";
import { MenuItemProps as AntMenuItemProps } from "antd/lib/menu/MenuItem";
import { useMemo } from "react";
import { useIntl } from "react-intl";
import Menu from "antd/lib/menu";
import { GlobalOutlined } from "@ant-design/icons";
import _at from "lodash/at";
import _compact from "lodash/compact";
import {
  ActionProps,
  CellSetSelection,
  DataVisualizationWidgetState,
  getAntMenuItemProps,
  withCube,
} from "@activeviam/activeui-sdk";
import { pluginKey } from "./pluginMenuItemGetCellLocation";
import { notifyMessage } from "../utils";
import { canGetCellLocationOnSelection } from "./canGetCellLocationOnSelection";

export const GetCellLocationMenuItem = withCube<
  ActionProps<DataVisualizationWidgetState, CellSetSelection> & AntMenuItemProps
>((props) => {
  const { formatMessage } = useIntl();
  const { cube, selection, widgetState } = props;

  // Narrows down the selection to tuples with valid cell values
  const selectedCells = useMemo(() => {
    if (!canGetCellLocationOnSelection(selection)) {
      return undefined;
    }

    // You can apply additional filtering of selected cells
    // (tuple) => tuple.dimensionName === "Measures" || !isTotal(getHierarchy(tuple, cube), tuple)

    return selection.cells;
  }, [cube, selection]);

  const logCellLocations = () => {
    selectedCells!.forEach(({ value, tuple }) => {
      console.log("Cell Value", value);
      console.log(
        "Cell Location",
        tuple.map((e) => [e.dimensionName, e.hierarchyName, ...e.namePath])
      );
    });

    notifyMessage("Get Cell Locations", "See the logs in console.");
  };

  const handleClick: AntMenuItemProps["onClick"] = (clickParam) => {
    if (props.onClick) {
      props.onClick(clickParam);
    }
    logCellLocations();
  };

  return selectedCells && widgetState.query.mdx ? (
    <Menu.Item {...getAntMenuItemProps(props)} onClick={handleClick}>
      <GlobalOutlined />
      {formatMessage({
        id: `aui.plugins.menu-item.${pluginKey}.getCellLocation`,
      })}
    </Menu.Item>
  ) : null;
});
