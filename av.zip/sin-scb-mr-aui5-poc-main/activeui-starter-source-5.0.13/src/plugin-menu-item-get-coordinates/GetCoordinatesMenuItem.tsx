/** @jsx jsx */
import { jsx } from "@emotion/core";
import { MenuItemProps as AntMenuItemProps } from "antd/lib/menu/MenuItem";
import { useIntl } from "react-intl";
import Menu from "antd/lib/menu";
import { GlobalOutlined } from "@ant-design/icons";
import _at from "lodash/at";
import _compact from "lodash/compact";
import {
  createFilter,
  Cube,
  DataVisualizationMappingField,
  DataVisualizationWidgetMapping,
  DataVisualizationWidgetState,
  getAntMenuItemProps,
  HierarchyCoordinates,
  HierarchyInMapping,
  LevelCoordinates,
  Mdx,
  MeasureInMapping,
  MenuItemProps,
  withCube,
} from "@activeviam/activeui-sdk";
import {
  isFilterOnMembers,
  isFilterOnTopBottomMembers,
  isFilterOnLowerOrGreaterValues,
  isFilterOnValuesRange,
  isFilterOnLowerOrGreaterCaptions,
  isFilterOnCaptionsRange,
  isFilterOnExistenceOfValue,
  isFilterOnDateRange,
  notifyMessage,
} from "../utils";
import { pluginKey } from "./pluginMenuItemGetCoordinates";

type AxisName = "rows" | "columns" | "measures";
const _pickAxises = (
  mapping: DataVisualizationWidgetMapping,
  names: AxisName[]
): DataVisualizationMappingField[] => _at(mapping, names).flat();

const _extractCoordinatesFromFilters = (
  filtersMdx: Mdx[],
  cube: Cube
): (LevelCoordinates | HierarchyCoordinates)[] => {
  const filters = filtersMdx.map((mdx) => createFilter(mdx, cube));
  const _rawCoordinates: (
    | LevelCoordinates
    | HierarchyCoordinates
    | undefined
  )[] = filters.map((filter) => {
    // https://activeui.activeviam.com/activeui/documentation/latest/docs/api/types/#filter
    if (isFilterOnMembers(filter) || isFilterOnTopBottomMembers(filter)) {
      const { dimensionName, hierarchyName } = filter;
      return { dimensionName, hierarchyName };
    } else if (
      isFilterOnLowerOrGreaterValues(filter) ||
      isFilterOnValuesRange(filter) ||
      isFilterOnLowerOrGreaterCaptions(filter) ||
      isFilterOnCaptionsRange(filter) ||
      isFilterOnLowerOrGreaterCaptions(filter) ||
      isFilterOnExistenceOfValue(filter) ||
      isFilterOnDateRange(filter)
    ) {
      const { dimensionName, hierarchyName, levelName } = filter;
      return { dimensionName, hierarchyName, levelName };
    }
    return undefined;
  });
  // Let's remove `undefined` values
  return _compact(_rawCoordinates);
};

const _extractCoordinates = (
  // https://activeui.activeviam.com/activeui/documentation/latest/docs/api/types/#datavisualizationwidgetmapping
  mapping: DataVisualizationWidgetMapping,
  filtersMdx: Mdx[],
  cube: Cube
): {
  levels: LevelCoordinates[];
  measures: string[];
  filters: (LevelCoordinates | HierarchyCoordinates)[];
} => {
  // https://activeui.activeviam.com/activeui/documentation/latest/docs/api/types/#datavisualizationmappingfield
  const mappingFields = _pickAxises(mapping, ["rows", "columns", "measures"]);
  const hierarchyFields = mappingFields.filter(
    (field) => field.type === "hierarchy"
  ) as HierarchyInMapping[];
  const levels: LevelCoordinates[] = hierarchyFields.map(
    ({ dimensionName, hierarchyName, levelName }) => ({
      dimensionName,
      hierarchyName,
      levelName,
    })
  );

  const measureFields = mappingFields.filter(
    (field) => field.type === "measure"
  ) as MeasureInMapping[];
  const measures = measureFields.map((field) => field.measureName);

  const filters = _extractCoordinatesFromFilters(filtersMdx, cube);
  return { levels, measures, filters };
};

/**
 * Displays a menu item allowing to get coordinates from the widget.
 */
export const GetCoordinatesMenuItem = withCube<
  MenuItemProps<DataVisualizationWidgetState>
>((props) => {
  const { formatMessage } = useIntl();
  const { cube } = props;
  const { mapping, filters: filtersMdx } = props.widgetState;
  const mdx = props.widgetState.query?.mdx;

  if (!mdx) {
    return null;
  }

  const logCoordinates = () => {
    const { levels, measures, filters } = _extractCoordinates(
      mapping,
      filtersMdx ?? [],
      cube
    );

    console.log("Levels", levels);
    console.log("Measures", measures);
    console.log("Filters", filters);

    notifyMessage("Get Coordinates", "See the logs in console.");
  };

  const handleClick: AntMenuItemProps["onClick"] = (clickParam) => {
    if (props.onClick) {
      props.onClick(clickParam);
    }
    logCoordinates();
  };

  return (
    <Menu.Item
      {...getAntMenuItemProps<DataVisualizationWidgetState>(props)}
      onClick={handleClick}
    >
      <GlobalOutlined />
      {formatMessage({
        id: `aui.plugins.menu-item.${pluginKey}.getCoordinates`,
      })}
    </Menu.Item>
  );
});
