export { pluginMenuItemGetCoordinates } from "./pluginMenuItemGetCoordinates";
