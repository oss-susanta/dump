import {
  DataVisualizationWidgetState,
  MenuItemPlugin,
} from "@activeviam/activeui-sdk";
import { GetCoordinatesMenuItem } from "./GetCoordinatesMenuItem";

export const pluginKey = "get-coordinates";

/**
 * {@link MenuItemPlugin} allowing to get the coordinates of the widget.
 */
export const pluginMenuItemGetCoordinates: MenuItemPlugin<DataVisualizationWidgetState> =
  {
    Component: GetCoordinatesMenuItem,
    key: pluginKey,
    translations: {
      "en-US": {
        getCoordinates: "Get coordinates",
      },
    },
  };
