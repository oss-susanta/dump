import { DashboardState } from "@activeviam/activeui-sdk";
import { notifyMessage } from "../utils";
import _ from "lodash";

export const handleWidgetChanges = (
  currentState: DashboardState<"deserialized"> | null,
  newState: DashboardState
) => {
  const { added, deleted } = _widgetDifferences(currentState, newState);

  if (deleted.length > 0) {
    notifyMessage("Widgets Deleted", deleted.join());
    console.log("Widgets Deleted", deleted.join());
  } else if (added.length > 0) {
    notifyMessage("Widgets Added", added.join());
    console.log("Widgets Added", added.join());
  }
};

const _widgetDifferences = (
  currentState: DashboardState<"deserialized"> | null,
  newState: DashboardState<"deserialized"> | null
): { added: string[]; deleted: string[] } => {
  const currentWidgetKeys = _uniqueWidgetKeys(currentState);
  const newWidgetKeys = _uniqueWidgetKeys(newState);

  const deleted = _.difference(currentWidgetKeys, newWidgetKeys);
  const added = _.difference(newWidgetKeys, currentWidgetKeys);
  return { added, deleted };
};

/**
 * Extract the widget keys in the format of "page_key|widget_key"
 *
 * @param dashboardState
 * @returns unique widget keys in the dashboard
 */
const _uniqueWidgetKeys = (
  dashboardState: DashboardState<"deserialized"> | null
) =>
  Object.entries((dashboardState && dashboardState.pages) || {}).flatMap(
    ([pageKey, pageState]) =>
      Object.keys(pageState.content).map((wKey) => pageKey + "|" + wKey)
  );
