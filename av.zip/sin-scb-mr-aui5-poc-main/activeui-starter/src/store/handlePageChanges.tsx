import { DashboardState } from "@activeviam/activeui-sdk";
import { notifyMessage } from "../utils";
import _ from "lodash";

export const handlePageChanges = (
  currentState: DashboardState<"deserialized"> | null,
  newState: DashboardState<"deserialized">
) => {
  const { added, deleted } = _pageDifferences(currentState, newState);

  if (deleted.length > 0) {
    notifyMessage("Pages Deleted", deleted.join());
    console.log("Pages Deleted", deleted.join());
  } else if (added.length > 0) {
    notifyMessage("Pages Added", added.join());
    console.log("Pages Added", added.join());
  }
};

const _pageDifferences = (
  currentState: DashboardState<"deserialized"> | null,
  newState: DashboardState<"deserialized">
): { added: string[]; deleted: string[] } => {
  const currentPageKeys = Object.keys(
    (currentState && currentState.pages) || {}
  );
  const newPageKeys = Object.keys(newState.pages || {});

  const deleted = _.difference(currentPageKeys, newPageKeys);
  const added = _.difference(newPageKeys, currentPageKeys);
  return { added, deleted };
};
