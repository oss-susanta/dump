import notification from "antd/lib/notification";

export function notifyMessage(message: string, description?: string) {
  notification.success({
    message,
    description,
    duration: 30,
    getContainer: () => document.getElementById("activeui-overlay-root")!,
  });
}
