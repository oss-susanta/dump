import { Filter, FilterOnMembers } from "@activeviam/activeui-sdk";

/**
 * Returns whether `filter` is a {@link FilterOnMembers}.
 */
export function isFilterOnMembers(filter: Filter): filter is FilterOnMembers {
  return filter.type === "members";
}
