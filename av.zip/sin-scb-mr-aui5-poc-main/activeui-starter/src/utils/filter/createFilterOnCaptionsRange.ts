import {
  HierarchyCoordinates,
  LevelName,
  FilterOnCaptionsRange,
} from "@activeviam/activeui-sdk";

/**
 * Returns  a {@link FilterOnCaptionsRange}.
 */
export function createFilterOnCaptionsRange(
  hierarchy: HierarchyCoordinates,
  levelName: LevelName,
  lowerToken: string,
  upperToken: string,
  isBetween: boolean
): FilterOnCaptionsRange {
  return {
    ...hierarchy,
    levelName,
    lowerToken,
    upperToken,
    isBetween,
    type: "captionsRange",
  };
}
