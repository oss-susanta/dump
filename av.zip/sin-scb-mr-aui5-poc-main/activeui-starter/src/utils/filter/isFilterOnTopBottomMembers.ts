import { Filter, FilterOnTopBottomMembers } from "@activeviam/activeui-sdk";

/**
 * Returns whether `filter` is a {@link FilterOnTopBottomMembers}.
 */
export function isFilterOnTopBottomMembers(
  filter: Filter
): filter is FilterOnTopBottomMembers {
  return filter.type === "topBottomMembers";
}
