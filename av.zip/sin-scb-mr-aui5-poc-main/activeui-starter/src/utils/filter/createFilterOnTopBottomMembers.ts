import {
  FilterOnTopBottomMembers,
  FilterScope,
  HierarchyCoordinates,
  MeasureName,
  TopBottomMode,
} from "@activeviam/activeui-sdk";

/**
 * Returns  a {@link FilterOnTopBottomMembers}.
 */
export function createFilterOnTopBottomMembers(
  hierarchy: HierarchyCoordinates,
  limit: number,
  levelIndex: number,
  topBottomMode: TopBottomMode,
  scope: FilterScope,
  measureName: MeasureName
): FilterOnTopBottomMembers {
  return {
    ...hierarchy,
    levelIndex,
    limit,
    measureName,
    scope,
    topBottomMode,
    type: "topBottomMembers",
  };
}
