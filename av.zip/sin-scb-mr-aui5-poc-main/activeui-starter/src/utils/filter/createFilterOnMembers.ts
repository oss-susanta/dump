import {
  FilterOnMembers,
  HierarchyCoordinates,
} from "@activeviam/activeui-sdk";

/**
 * Returns  a {@link FilterOnMembers}.
 */
export function createFilterOnMembers(
  hierarchy: HierarchyCoordinates,
  members: string[][]
): FilterOnMembers {
  return {
    ...hierarchy,
    members,
    type: "members",
  };
}
