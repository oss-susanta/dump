import { Filter, FilterOnValuesRange } from "@activeviam/activeui-sdk";

/**
 * Returns whether `filter` is a {@link FilterOnValuesRange}.
 */
export function isFilterOnValuesRange(
  filter: Filter
): filter is FilterOnValuesRange {
  return filter.type === "valuesRange";
}
