import { Filter, FilterOnCaptionsRange } from "@activeviam/activeui-sdk";

/**
 * Returns whether `filter` is a {@link FilterOnCaptionsRange}.
 */
export function isFilterOnCaptionsRange(
  filter: Filter
): filter is FilterOnCaptionsRange {
  return filter.type === "captionsRange";
}
