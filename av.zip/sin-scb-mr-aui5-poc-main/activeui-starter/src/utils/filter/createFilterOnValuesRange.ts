import {
  HierarchyCoordinates,
  LevelName,
  FilterOnValuesRange,
  MeasureName,
} from "@activeviam/activeui-sdk";

/**
 * Returns  a {@link FilterOnValuesRange}.
 */
export function createFilterOnValuesRange(
  hierarchy: HierarchyCoordinates,
  levelName: LevelName,
  measureName: MeasureName,
  lowerLimit: number,
  upperLimit: number,
  isBetween: boolean
): FilterOnValuesRange {
  return {
    ...hierarchy,
    levelName,
    measureName,
    lowerLimit,
    upperLimit,
    isBetween,
    type: "valuesRange",
  };
}
