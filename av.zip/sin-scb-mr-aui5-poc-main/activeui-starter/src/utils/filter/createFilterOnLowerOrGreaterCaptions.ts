import {
  HierarchyCoordinates,
  LevelName,
  LowerOrGreaterMode,
  FilterOnLowerOrGreaterCaptions,
} from "@activeviam/activeui-sdk";

/**
 * Returns  a {@link FilterOnLowerOrGreaterCaptions}.
 */
export function createFilterOnLowerOrGreaterCaptions(
  hierarchy: HierarchyCoordinates,
  levelName: LevelName,
  token: string,
  lowerOrGreaterMode: LowerOrGreaterMode
): FilterOnLowerOrGreaterCaptions {
  return {
    ...hierarchy,
    levelName,
    token,
    lowerOrGreaterMode,
    type: "lowerOrGreaterCaptions",
  };
}
