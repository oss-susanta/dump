import {
  HierarchyCoordinates,
  FilterOnLowerOrGreaterValues,
  LevelName,
  LowerOrGreaterMode,
  MeasureName,
} from "@activeviam/activeui-sdk";

/**
 * Returns  a {@link FilterOnLowerOrGreaterValue}.
 */
export function createFilterOnLowerOrGreaterValue(
  hierarchy: HierarchyCoordinates,
  lowerOrGreaterLimit: number,
  levelName: LevelName,
  lowerOrGreaterMode: LowerOrGreaterMode,
  measureName: MeasureName
): FilterOnLowerOrGreaterValues {
  return {
    ...hierarchy,
    lowerOrGreaterLimit,
    levelName,
    lowerOrGreaterMode,
    measureName,
    type: "lowerOrGreaterValue",
  };
}
