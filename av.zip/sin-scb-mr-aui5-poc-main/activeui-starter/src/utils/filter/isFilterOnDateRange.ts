import { Filter, FilterOnDateRange } from "@activeviam/activeui-sdk";

/**
 * Returns whether `filter` is a {@link FilterOnDateRange}.
 */
export function isFilterOnDateRange(
  filter: Filter
): filter is FilterOnDateRange {
  return filter.type === "dateRange";
}
