import {
  HierarchyCoordinates,
  FilterOnDateRange,
} from "@activeviam/activeui-sdk";

/**
 * Returns  a {@link FilterOnDateRange}.
 */
export function createFilterOnDateRange(
  hierarchy: HierarchyCoordinates,
  levelName: string,
  startDate: Date,
  endDate: Date,
  isRollingDate: boolean
): FilterOnDateRange {
  return {
    ...hierarchy,
    levelName,
    startDate,
    endDate,
    isRollingDate,
    type: "dateRange",
  };
}
