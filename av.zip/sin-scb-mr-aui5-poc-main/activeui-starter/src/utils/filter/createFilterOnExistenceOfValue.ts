import {
  HierarchyCoordinates,
  LevelName,
  FilterOnExistenceOfValue,
  MeasureName,
} from "@activeviam/activeui-sdk";

/**
 * Returns  a {@link FilterOnExistenceOfValue}.
 */
export function createFilterOnExistenceOfValue(
  hierarchy: HierarchyCoordinates,
  doesExist: boolean,
  levelName: LevelName,
  measureName: MeasureName
): FilterOnExistenceOfValue {
  return {
    ...hierarchy,
    doesExist,
    levelName,
    measureName,
    type: "existenceOfValue",
  };
}
