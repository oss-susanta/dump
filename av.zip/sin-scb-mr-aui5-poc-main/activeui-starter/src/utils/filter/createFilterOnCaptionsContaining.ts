import {
  HierarchyCoordinates,
  LevelName,
  FilterOnCaptionContaining,
  ContainingMode,
} from "@activeviam/activeui-sdk";

/**
 * Returns  a {@link FilterOnLowerOrGreaterCaptions}.
 */
export function createFilterOnCaptionsContaining(
  hierarchy: HierarchyCoordinates,
  levelName: LevelName,
  token: string,
  containingMode: ContainingMode
): FilterOnCaptionContaining {
  return {
    ...hierarchy,
    levelName,
    token,
    containingMode,
    type: "captionsContaining",
  };
}
