import {
  LevelCoordinates,
  MdxLevelCompoundIdentifier,
} from "@activeviam/activeui-sdk";

/**
 * Returns the {@link MdxLevelCompoundIdentifier} corresponding to the given level coordinates.
 */
export function createMdxLevelCompoundIdentifier({
  dimensionName,
  hierarchyName,
  levelName,
}: LevelCoordinates): MdxLevelCompoundIdentifier {
  return {
    elementType: "CompoundIdentifier",
    type: "level",
    identifiers: [dimensionName, hierarchyName, levelName].map((value) => ({
      elementType: "Identifier",
      quoting: "QUOTED",
      value,
    })),
    dimensionName,
    hierarchyName,
    levelName,
  };
}
