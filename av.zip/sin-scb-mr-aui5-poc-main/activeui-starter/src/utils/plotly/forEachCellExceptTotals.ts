import { HierarchyIndicesInCellSet } from "./getHierarchyIndicesInCellSet";
import { forEachCell } from "./forEachCell";
import { Cell, CellSet, quote, Tuple } from "@activeviam/activeui-sdk";

/**
 * Executes the given callback for each cell in `data`, except those representing totals.
 */
export const forEachCellExceptTotals = (
  data: CellSet,
  hierarchyIndicesInCellSet: HierarchyIndicesInCellSet,
  callback: (args: {
    cell: Cell | null;
    cellIndex: number | null;
    columnIndex: number;
    tuple: Tuple | null;
    rowIndex: number;
  }) => void
): void => {
  forEachCell(
    data,
    hierarchyIndicesInCellSet,
    ({ cell, cellIndex, columnIndex, tuple, rowIndex }) => {
      // The tuple is undefined in the case of a lazy-loaded cellset, if it is out of the currently loaded range.
      // In this case, it is considered a leaf.
      const isLeaf =
        !tuple ||
        tuple.every(({ dimensionName, hierarchyName, ...member }) => {
          if (member === undefined) {
            return true;
          }
          const { axisIndex, hierarchyIndex } =
            hierarchyIndicesInCellSet[quote(dimensionName, hierarchyName)];
          const maxLevelDepth =
            data.axes[axisIndex].maxLevelPerHierarchy[hierarchyIndex];
          // Every cell with a member that isn't on the deepest level used on its hierarchy is a total.
          return member.namePath.length === maxLevelDepth;
        });

      if (isLeaf) {
        callback({ cell, cellIndex, columnIndex, tuple, rowIndex });
      }
    }
  );
};
