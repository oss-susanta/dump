import { forEachCellExceptTotals } from "./forEachCellExceptTotals";
import { getHierarchyIndicesInCellSet } from "./getHierarchyIndicesInCellSet";
import _last from "lodash/last";
import _first from "lodash/first";
import { axisIds, CellSet, Member } from "@activeviam/activeui-sdk";

const ALL_MEMBER = "AllMember";

function isAllMemberExists(values: string[]): boolean {
  return _first(values) === ALL_MEMBER;
}

function fillValuesFromCellSet(
  data: CellSet,
  values: (number | string)[][]
): void {
  const hierarchyIndicesInCellSet = getHierarchyIndicesInCellSet(data);
  forEachCellExceptTotals(
    data,
    hierarchyIndicesInCellSet,
    ({ cell, columnIndex, rowIndex }) => {
      if (cell) {
        values[columnIndex][rowIndex] = cell.value;
      }
    }
  );
}

function getColumnsAxisTitle(data: CellSet): string | undefined {
  return (
    (data.axes[axisIds.columns] &&
      data.axes[axisIds.columns].hierarchies[0] &&
      data.axes[axisIds.columns].hierarchies[0].hierarchy) ||
    undefined
  );
}

function getRowsAxisTitle(data: CellSet): string | undefined {
  return (
    (data.axes[axisIds.rows] &&
      data.axes[axisIds.rows].hierarchies[0] &&
      data.axes[axisIds.rows].hierarchies[0].hierarchy) ||
    undefined
  );
}

function getMeasuresAxisTitle(data: CellSet): string | undefined {
  const columnsAxis = data.axes[axisIds.columns];
  return (
    _last(
      columnsAxis.positions[0] &&
        columnsAxis.positions[0][1] &&
        columnsAxis.positions[0][1].captionPath
    ) || undefined
  );
}

function getMemberCaptions(members: Member[][]): string[] {
  return members.map((member) => {
    const captionArr = member[0].captionPath;
    return captionArr[captionArr.length - 1];
  });
}

/**
 * Create Plotly data object to render the chart from the given MDX result of type `CellSet`
 * WARNING: This is tested with two chart types, `Surface chart` and `Heatmap`.
 *
 * @param data CellSet
 * @returns Plotly data for "x", "y" and "z"
 */
export function getChartValues(data?: CellSet): {
  x: { title: string; values: string[] };
  y: { title: string; values: string[] };
  z: { title: string; values: (string | number)[][] };
} {
  if (!data || data.axes.length !== 2) {
    return {
      x: { title: "x", values: [] },
      y: { title: "y", values: [] },
      z: { title: "z", values: [[]] },
    };
  }

  const [columnsAxis, rowsAxis] = data.axes;

  const columnsAxisTitle = getColumnsAxisTitle(data);
  const rowsAxisTitle = getRowsAxisTitle(data);
  const measuresAxisTitle = getMeasuresAxisTitle(data);

  const numberOfRows = rowsAxis.positions.length;
  const numberOfColumns = columnsAxis.positions.length;

  let rowValues = getMemberCaptions(rowsAxis.positions);
  let columnValues = getMemberCaptions(columnsAxis.positions);
  let measureValues: (number | string)[][] = Array(numberOfColumns)
    .fill(null)
    .map(() => Array(numberOfRows).fill(null));

  fillValuesFromCellSet(data, measureValues);

  // Remove AllMember data
  if (isAllMemberExists(columnValues)) {
    columnValues = columnValues.slice(1);
    measureValues = measureValues.slice(1);
  }
  if (isAllMemberExists(rowValues)) {
    rowValues = rowValues.slice(1);
    measureValues = measureValues.map((row) => row.slice(1));
  }

  return {
    x: { title: rowsAxisTitle || "x", values: rowValues },
    y: { title: columnsAxisTitle || "y", values: columnValues },
    z: { title: measuresAxisTitle || "z", values: measureValues },
  };
}
