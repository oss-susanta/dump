import _keyBy from "lodash/keyBy";
import {
  CellPlugin,
  CellStylePlugin,
  MenuItemPlugin,
  PluginRegistry,
  TitleBarButtonPlugin,
  WidgetPlugin,
  pluginWidgetPivotTable,
  pluginWidgetTable,
  pluginWidgetTreeTable,
  pluginTitleBarButtonFullScreen,
  pluginMenuItemRemoveWidget,
  SelectionListenerPlugin,
} from "@activeviam/activeui-sdk";
import _merge from "lodash/merge";
import { pluginMenuItemGetCoordinates } from "./plugin-menu-item-get-coordinates";
import { pluginWidgetFetchMembers } from "./plugin-widget-fetch-members";
import { pluginSelectionListenerGetCellLocation } from "./plugin-selection-listener-get-cell-location";

const cellPlugins: Array<CellPlugin<any>> = [];

const cellStylePlugins: Array<CellStylePlugin<any>> = [];

const selectionListenerPlugins: Array<SelectionListenerPlugin<any, any>> = [
  pluginSelectionListenerGetCellLocation,
];

const menuItemPlugins: Array<MenuItemPlugin<any, any>> = [
  pluginMenuItemGetCoordinates,
];

const titleBarButtonPlugins: Array<TitleBarButtonPlugin<any>> = [];

pluginWidgetFetchMembers.titleBarButtons = [
  ...(pluginWidgetFetchMembers.titleBarButtons || []),
  pluginTitleBarButtonFullScreen.key,
];
pluginWidgetFetchMembers.menuItems = [
  ...(pluginWidgetFetchMembers.menuItems || []),
  pluginMenuItemRemoveWidget.key,
];

// Order matters: it controls the order of the icons in the widget ribbons.
const widgetPlugins: Array<WidgetPlugin<any, any>> = [pluginWidgetFetchMembers];

const plugins: PluginRegistry = {
  cell: _keyBy(cellPlugins, "key"),
  "cell-style": _keyBy(cellStylePlugins, "key"),
  "selection-listener": _keyBy(selectionListenerPlugins, "key"),
  "menu-item": _keyBy(menuItemPlugins, "key"),
  "titlebar-button": _keyBy(titleBarButtonPlugins, "key"),
  widget: _keyBy(widgetPlugins, "key"),
};

export const registerMarketRiskPlugins = (
  pluginRegistry: PluginRegistry
): void => {
  _merge(pluginRegistry.cell, plugins.cell);
  _merge(pluginRegistry["cell-style"], plugins["cell-style"]);
  _merge(pluginRegistry["selection-listener"], plugins["selection-listener"]);
  _merge(pluginRegistry["menu-item"], plugins["menu-item"]);
  _merge(pluginRegistry["titlebar-button"], plugins["titlebar-button"]);
  _merge(pluginRegistry.widget, plugins.widget);

  const widgetPivotTable = pluginRegistry.widget![pluginWidgetPivotTable.key];
  const widgetTreeTable = pluginRegistry.widget![pluginWidgetTreeTable.key];
  const widgetTable = pluginRegistry.widget![pluginWidgetTable.key];

  [widgetPivotTable, widgetTreeTable, widgetTable].forEach((widget) => {
    widget.menuItems = [
      ...(widget.menuItems || []),
      pluginMenuItemGetCoordinates.key,
    ];
    widget.selectionListener = pluginSelectionListenerGetCellLocation.key;
  });
};
