/** @jsx jsx */
import MenuItem, {
  MenuItemProps as AntMenuItemProps,
} from "antd/lib/menu/MenuItem";

import { jsx } from "@emotion/core";
import { FC } from "react";
import { FilterOutlined } from "@ant-design/icons";
import { useDispatch, useSelector } from "react-redux";
import {
  getDashboardState,
  useDataModels,
  DashboardUpdatedAction,
  HierarchyCoordinates,
  getCube,
  TopBottomMode,
  FilterScope,
} from "@activeviam/activeui-sdk";
import { createFilterOnTopBottomMembers, notifyMessage } from "../../utils";
import { _getFilteredDashboardState } from "./_getFilteredDashboardState";

type FilterOnTopBottomMembersMenuItemProps = AntMenuItemProps;

/**
 * Menu item to apply FilterOnTopBottomMembers to the widgets.
 */
export const FilterOnTopBottomMembersMenuItem: FC<
  FilterOnTopBottomMembersMenuItemProps
> = (props) => {
  // https://activeui.activeviam.com/activeui/documentation/latest/docs/api/functions/#getdashboardstate
  const dashboardState = useSelector(getDashboardState);

  // https://activeui.activeviam.com/activeui/documentation/latest/docs/api/hooks/#usedatamodels
  const dataModels = useDataModels();

  const dispatch = useDispatch();

  if (!dashboardState) {
    return null;
  }

  const applyFilter = () => {
    // https://activeui.activeviam.com/activeui/documentation/latest/docs/api/functions/#getcube
    const serverKey = Object.keys(window.env.activePivotServers)[0];
    const cube = getCube(dataModels[serverKey], "EquityDerivativesCube");

    const hierarchy: HierarchyCoordinates = {
      dimensionName: "Booking",
      hierarchyName: "Desk",
    };
    // Create filter on "Top 5 BusinessUnit with highest pnl.SUM"
    const levelIndex = 2; // (1)LegalEntity (2)BusinessUnit (3)Desk (4)BookId
    const limit = 5;
    const topBottomMode: TopBottomMode = "TopCount";
    const measureName = "pnl.SUM";
    const scope: FilterScope = "overall";
    const filter = createFilterOnTopBottomMembers(
      hierarchy,
      limit,
      levelIndex,
      topBottomMode,
      scope,
      measureName
    );

    // Apply filter to dashboard state
    const updatedDashboardState = _getFilteredDashboardState(
      dashboardState,
      [filter],
      cube
    );

    // Update the dashboard
    // https://activeui.activeviam.com/activeui/documentation/latest/docs/api/types/#dashboardupdatedaction
    const action: DashboardUpdatedAction = {
      type: "dashboardUpdated",
      dashboardState: updatedDashboardState,
    };
    dispatch(action);

    notifyMessage("Filter on Top/Bottom Members", "See filter section.");
  };

  const handleClicked: AntMenuItemProps["onClick"] = async (param) => {
    // Closes the context menu item.
    if (props.onClick) {
      props.onClick(param);
    }
    applyFilter();
  };

  return (
    <MenuItem {...props} onClick={handleClicked}>
      <FilterOutlined />
      Filter on Top/Bottom Members
    </MenuItem>
  );
};
