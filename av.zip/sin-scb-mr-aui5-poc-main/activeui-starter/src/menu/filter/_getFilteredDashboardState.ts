import { produce } from "immer";
import {
  Cube,
  DashboardPageState,
  DashboardState,
  Filter,
  isWidgetWithQueryState,
} from "@activeviam/activeui-sdk";
import { addFilters } from "./addFilters";

export function _getFilteredDashboardState(
  dashboardState: DashboardState,
  addedFilters: Filter[],
  cube: Cube,
  scope: "pages" | "widgets" = "widgets"
): DashboardState {
  return produce(dashboardState, (draft) => {
    // loop through each page in dashboard
    Object.keys(draft.pages).forEach((pageKey) => {
      const pageState = draft.pages[pageKey];
      if (scope === "pages") {
        _addPageFilters({ pageState, addedFilters, cube });
      } else if (scope === "widgets") {
        _addWidgetFilters({ pageState, addedFilters, cube });
      } else {
        console.error(`Invalid parameter scope: ${scope}`);
      }
    });
  });
}

function _addPageFilters({
  pageState,
  addedFilters,
  cube,
}: {
  pageState: DashboardPageState;
  addedFilters: Filter[];
  cube: Cube;
}) {
  if (!pageState.filters) {
    pageState.filters = [];
  }
  addFilters({
    existingMdxFilters: pageState.filters,
    addedFilters,
    cube,
  });
}

function _addWidgetFilters({
  pageState,
  addedFilters,
  cube,
}: {
  pageState: DashboardPageState;
  addedFilters: Filter[];
  cube: Cube;
}) {
  // loop through each widget in a page
  Object.keys(pageState.content).forEach((leafKey) => {
    const widgetState = pageState.content[leafKey];
    //https://activeui.activeviam.com/activeui/documentation/latest/docs/api/functions/#iswidgetwithquerystate
    if (isWidgetWithQueryState(widgetState)) {
      if (!widgetState.filters) {
        widgetState.filters = [];
      }
      addFilters({
        existingMdxFilters: widgetState.filters,
        addedFilters,
        cube,
      });
    }
  });
}
