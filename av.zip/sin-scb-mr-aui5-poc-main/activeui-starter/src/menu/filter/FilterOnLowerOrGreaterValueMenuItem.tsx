/** @jsx jsx */
import MenuItem, {
  MenuItemProps as AntMenuItemProps,
} from "antd/lib/menu/MenuItem";

import { jsx } from "@emotion/core";
import { FC } from "react";
import { FilterOutlined } from "@ant-design/icons";
import { useDispatch, useSelector } from "react-redux";
import {
  getDashboardState,
  useDataModels,
  DashboardUpdatedAction,
  HierarchyCoordinates,
  getCube,
  LowerOrGreaterMode,
} from "@activeviam/activeui-sdk";
import { createFilterOnLowerOrGreaterValue, notifyMessage } from "../../utils";
import { _getFilteredDashboardState } from "./_getFilteredDashboardState";

type FilterOnLowerOrGreaterValueMenuItemProps = AntMenuItemProps;

/**
 * Menu item to apply FilterOnLowerOrGreaterValue to the widgets.
 */
export const FilterOnLowerOrGreaterValueMenuItem: FC<
  FilterOnLowerOrGreaterValueMenuItemProps
> = (props) => {
  // https://activeui.activeviam.com/activeui/documentation/latest/docs/api/functions/#getdashboardstate
  const dashboardState = useSelector(getDashboardState);

  // https://activeui.activeviam.com/activeui/documentation/latest/docs/api/hooks/#usedatamodels
  const dataModels = useDataModels();

  const dispatch = useDispatch();

  if (!dashboardState) {
    return null;
  }

  const applyFilter = () => {
    // https://activeui.activeviam.com/activeui/documentation/latest/docs/api/functions/#getcube
    const serverKey = Object.keys(window.env.activePivotServers)[0];
    const cube = getCube(dataModels[serverKey], "EquityDerivativesCube");

    const hierarchy: HierarchyCoordinates = {
      dimensionName: "Currency",
      hierarchyName: "Currency",
    };
    // Create filter on "Currency with contributors.COUNT < 150"
    const lowerOrGreaterLimit = 150;
    const levelName = "Currency";
    const lowerOrGreaterMode: LowerOrGreaterMode = "Lower";
    const measureName = "contributors.COUNT";
    const filter = createFilterOnLowerOrGreaterValue(
      hierarchy,
      lowerOrGreaterLimit,
      levelName,
      lowerOrGreaterMode,
      measureName
    );

    // Apply filter to dashboard state
    const updatedDashboardState = _getFilteredDashboardState(
      dashboardState,
      [filter],
      cube
    );

    // Update the dashboard
    // https://activeui.activeviam.com/activeui/documentation/latest/docs/api/types/#dashboardupdatedaction
    const action: DashboardUpdatedAction = {
      type: "dashboardUpdated",
      dashboardState: updatedDashboardState,
    };
    dispatch(action);

    notifyMessage("Filter on Lower/Greater Value", "See filter section.");
  };

  const handleClicked: AntMenuItemProps["onClick"] = async (param) => {
    // Closes the context menu item.
    if (props.onClick) {
      props.onClick(param);
    }
    applyFilter();
  };

  return (
    <MenuItem {...props} onClick={handleClicked}>
      <FilterOutlined />
      Filter on Lower/Greater Value
    </MenuItem>
  );
};
