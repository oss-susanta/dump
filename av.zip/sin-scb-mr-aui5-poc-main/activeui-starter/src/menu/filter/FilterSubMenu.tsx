/** @jsx jsx */
import SubMenu from "antd/lib/menu/SubMenu";

import { jsx } from "@emotion/core";
import { FC } from "react";
import { useIsLocationDashboard } from "../../utils";

/**
 * Submenu containing menu items specific to user project.
 */
export const FilterSubMenu: FC<{}> = (props) => {
  const isLocationDashboard = useIsLocationDashboard();

  return isLocationDashboard ? <SubMenu title="Filter" {...props} /> : null;
};
