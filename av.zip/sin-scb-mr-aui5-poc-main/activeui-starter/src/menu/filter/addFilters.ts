import {
  Cube,
  createFilter,
  Mdx,
  Filter,
  createMdxForFilter,
} from "@activeviam/activeui-sdk";
import { areHierarchiesEqual } from "../../utils";

/**
 * For each filter in `addedFilters`:
 *   - if `existingMdxFilters` contains the same type of filter on the same hierarchy, replaces it with the addedFilter.
 *   - otherwise adds the addedFilter at the end of the array.
 *
 * Mutates `existingMdxFilters`.
 */
export function addFilters({
  existingMdxFilters,
  addedFilters,
  cube,
}: {
  existingMdxFilters: Mdx[];
  addedFilters: Filter[];
  cube: Cube;
}): void {
  const existingFilters = existingMdxFilters.map((existingMdxFilter) =>
    createFilter(existingMdxFilter, cube)
  );

  addedFilters.forEach((addedFilter) => {
    //https://activeui.activeviam.com/activeui/documentation/latest/docs/api/functions#createmdxforfilter
    const addedFilterMdx = createMdxForFilter(addedFilter, cube);

    const indexOfFirstFilterOnMembers = existingFilters.findIndex(
      (existingFilter) => {
        return (
          existingFilter.type === addedFilter.type &&
          areHierarchiesEqual(addedFilter, existingFilter)
        );
      }
    );

    if (indexOfFirstFilterOnMembers !== -1) {
      existingMdxFilters[indexOfFirstFilterOnMembers] = addedFilterMdx;
    } else {
      existingMdxFilters.push(addedFilterMdx);
    }
  });
}
