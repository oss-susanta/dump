import { Configuration } from "@activeviam/activeui-sdk";
import { FilterSubMenu } from "./filter/FilterSubMenu";
import { FilterOnMembersMenuItem } from "./filter/FilterOnMembersMenuItem";
import { FilterOnTopBottomMembersMenuItem } from "./filter/FilterOnTopBottomMembersMenuItem";
import { FilterOnLowerOrGreaterValueMenuItem } from "./filter/FilterOnLowerOrGreaterValueMenuItem";

export const registerApplicationMenu = (configuration: Configuration) => {
  configuration.leftApplicationMenu = [
    ...configuration.leftApplicationMenu,
    {
      key: "CustomSubMenu",
      component: FilterSubMenu,
      children: [
        {
          key: "FilterOnMembersMenuItem",
          component: FilterOnMembersMenuItem,
        },
        {
          key: "FilterOnTopBottomMembersMenuItem",
          component: FilterOnTopBottomMembersMenuItem,
        },
        {
          key: "FilterOnLowerOrGreaterValueMenuItem",
          component: FilterOnLowerOrGreaterValueMenuItem,
        },
      ],
    },
  ];
};
