import { CellSetSelection, Tuple } from "@activeviam/activeui-sdk";
import _every from "lodash/every";

/**
 *  Returns `true` if the selection can give a valid cell location, `false` otherwise.
 */
export function canGetCellLocationOnSelection(
  selection: CellSetSelection | undefined
): selection is CellSetSelection & {
  cells: [
    {
      tuple: Tuple;
      value: number | string;
    }
  ];
} {
  // You can print out the selection object to see the details of current cell location.
  // console.log("selection", selection);

  // No selection is made.
  if (selection === undefined) {
    return false;
  }

  // On selection that include headers
  if (selection.axes && selection.axes.length > 0) {
    return false;
  }

  // selection exists with an empty `selection.cells`.
  if (!(selection.cells && selection.cells.length > 0)) {
    return false;
  }

  // selection on multiple cells
  // if (selection.cells.length !== 1) {
  //   return false;
  // }

  // all the selected cells should have values
  return _every(selection.cells, (e) => e.value !== undefined);
}
