import { FC, useEffect } from "react";
import { pluginKey } from "./pluginSelectionListenerGetCellLocation";
import { canGetCellLocationOnSelection } from "./canGetCellLocationOnSelection";
import {
  CellSetCellsSelection,
  CellSetSelection,
  DataVisualizationWidgetState,
  isWidgetInDashboard,
  Tuple,
  WidgetPluginProps,
} from "@activeviam/activeui-sdk";
import { notifyMessage } from "../utils";

const _logCellLocations = (
  selectedCells:
    | (CellSetCellsSelection &
        [
          {
            tuple: Tuple;
            value: string | number;
          }
        ])
    | undefined
) => {
  selectedCells!.forEach(({ value, tuple }) => {
    console.log("Cell Value", value);
    console.log(
      "Cell Location",
      tuple.map((e) => [e.dimensionName, e.hierarchyName, ...e.namePath])
    );
  });

  notifyMessage("Get Cell Locations", "See the logs in console.");
};

export const SelectionListenerGetCellLocation: FC<
  WidgetPluginProps<DataVisualizationWidgetState, CellSetSelection> & {
    children: JSX.Element;
    selection?: CellSetSelection;
  }
> = (props) => {
  useEffect(() => {
    if (
      !isWidgetInDashboard<DataVisualizationWidgetState, CellSetSelection>(
        props
      )
    ) {
      throw new Error(
        `The "${pluginKey}" selection listener plugin cannot be used outside a dashboard.`
      );
    }

    const { selection } = props;

    // Narrows down the selection to tuples with valid cell values
    if (!canGetCellLocationOnSelection(selection)) {
      // You can apply additional filtering of selected cells
      // (tuple) => tuple.dimensionName === "Measures" || !isTotal(getHierarchy(tuple, cube), tuple)
      // Do nothing
    } else {
      _logCellLocations(selection.cells);
    }
  }, [props.selection]);

  return props.children;
};
