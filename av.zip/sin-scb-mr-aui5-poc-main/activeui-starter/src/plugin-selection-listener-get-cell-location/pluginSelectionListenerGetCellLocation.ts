import { DataVisualizationWidgetState } from "@activeviam/plugin-widget";
import { SelectionListenerPlugin } from "@activeviam/plugin-selection-listener";
import { CellSetSelection } from "@activeviam/selection";

import { SelectionListenerGetCellLocation } from "./SelectionListenerGetCellLocation";

export const pluginKey = "get-cell-location";

/**
 * {@link SelectionListenerPlugin} getting the cell location from the selection on the target widget.
 */
export const pluginSelectionListenerGetCellLocation: SelectionListenerPlugin<
  DataVisualizationWidgetState,
  CellSetSelection
> = {
  key: pluginKey,
  SelectionListener: SelectionListenerGetCellLocation,
};
