import {
  ExtensionModule,
  pluginWidgetPivotTable,
} from "@activeviam/activeui-sdk";
import { withSandboxClients } from "@activeviam/sandbox-clients";
import _merge from "lodash/merge";
import { plugins } from "./plugins";
import { registerApplicationMenu } from "./menu";
import { registerStoreEnhancers } from "./store";
import { registerMarketRiskPlugins } from "./pluginsMarketRisk";
import { registerDrawers } from "./drawers";

const extension: ExtensionModule = {
  activate: async (configuration) => {
    _merge(configuration.pluginRegistry, plugins);
    configuration.applicationName = "ActiveUI";
    configuration.initialDashboardPageState = {
      content: { "0": pluginWidgetPivotTable.initialState },
      layout: {
        children: [
          {
            leafKey: "0",
            size: 1,
          },
        ],
        direction: "row",
      },
    };
    configuration.higherOrderComponents = [withSandboxClients];
    registerDrawers(configuration);
    registerApplicationMenu(configuration);
    registerStoreEnhancers(configuration);
    registerMarketRiskPlugins(configuration.pluginRegistry);
  },
};

export default extension;
