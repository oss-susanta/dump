import React from "react";
import { DeploymentUnitOutlined } from "@ant-design/icons";

/**
 * Large icon of the 3D chart, usable to represent in the widgets ribbon.
 */
export const Icon3dChart = () => (
  <DeploymentUnitOutlined style={{ fontSize: "25px", marginBottom: "2px" }} />
);
