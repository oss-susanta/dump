import {
  CellSetSelection,
  DataVisualizationContentEditor,
  DataVisualizationQueryEditor,
  FiltersEditor,
  PlotlyStyle,
  PlotlyWidgetState,
  WidgetAttributes,
  WidgetPlugin,
  withQueryResult,
} from "@activeviam/activeui-sdk";
import { Icon3dChart } from "./Icon3dChart";
import { Plotly3DSurfaceChart } from "./Plotly3DSurfaceChart";

const widgetKey = "plotly-3dsurface-chart";

const attributes: WidgetAttributes = {
  xAxis: {
    role: "primaryOrdinal",
    isMainAxis: true,
    maxNumberOfFields: 1,
  },
  yAxis: {
    role: "secondaryOrdinal",
    maxNumberOfFields: 1,
  },
  values: {
    role: "primaryNumeric",
    maxNumberOfFields: 1,
  },
};

const initialState: PlotlyWidgetState = {
  widgetKey,
  query: {
    updateMode: "once",
  },
  mapping: {
    xAxis: [],
    yAxis: [],
    values: [],
  },
};

/**
 * Data visualization {@link WidgetPlugin} displaying a Plotly 3D surface chart.
 */
export const pluginWidgetPlotly3DSurfaceChart: WidgetPlugin<
  PlotlyWidgetState,
  CellSetSelection,
  PlotlyStyle
> = {
  attributes,
  category: "dataVisualization",
  subCategory: "line",
  Component: withQueryResult(Plotly3DSurfaceChart),
  contentEditor: DataVisualizationContentEditor,
  queryEditor: DataVisualizationQueryEditor,
  filtersEditor: FiltersEditor,
  Icon: Icon3dChart,
  key: widgetKey,
  initialState,
  contextMenuItems: [],
  menuItems: [],
  titleBarButtons: [],
  translations: {
    "en-US": {
      key: "3D surface chart",
      defaultName: "New 3D surface chart",
    },
  },
};
