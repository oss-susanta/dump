import {
  Configuration,
  drawerQueryEditor,
  drawerStateEditor,
} from "@activeviam/activeui-sdk";

export const registerDrawers = (configuration: Configuration) => {
  configuration.drawers = [
    ...configuration.drawers,
    drawerQueryEditor,
    drawerStateEditor,
  ];
};
