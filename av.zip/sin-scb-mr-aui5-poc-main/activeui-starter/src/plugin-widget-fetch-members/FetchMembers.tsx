/** @jsx jsx */
import { jsx } from "@emotion/core";
import { FC } from "react";
import Select from "antd/lib/select";

import {
  LevelCoordinates,
  Query,
  useQueryResult,
  WidgetPluginProps,
  MdxString,
  quote,
  stringify,
  MdxExpression,
  MdxSelect,
} from "@activeviam/activeui-sdk";
import { createMdxLevelCompoundIdentifier } from "../utils";

const _buildMdxQuery = (
  level: LevelCoordinates,
  cubeName: string
): Query<MdxString> => {
  const membersExpression: MdxExpression = {
    arguments: [createMdxLevelCompoundIdentifier(level)],
    elementType: "Function",
    name: "AllMembers", // or "Members"
    syntax: "Property",
  };

  const selectMembersMdx: MdxSelect = {
    axes: [
      {
        elementType: "Axis",
        name: "ROWS",
        nonEmpty: false,
        properties: [],
        expression: membersExpression,
      },
    ],
    elementType: "Select",
    from: {
      cubeName: cubeName,
      elementType: "From",
    },
    withClause: [],
  };

  return {
    mdx: stringify(selectMembersMdx),
    // Alternatively, you can just build the MDX query string
    // mdx: `SELECT {[${level.dimensionName}].[${level.hierarchyName}].[${level.levelName}]} ON ROWS FROM [${cubeName}]`,
    updateMode: "once",
  };
};

export const FetchMembers: FC<WidgetPluginProps> = (props) => {
  const serverKey = "Ranch 5.11";
  const cubeName = "EquityDerivativesCube";
  const level: LevelCoordinates = {
    dimensionName: "Currency",
    hierarchyName: "Currency",
    levelName: "Currency",
  };

  const query = _buildMdxQuery(level, cubeName);

  const { data, error, isLoading } = useQueryResult({
    queryId: "fetch-members",
    serverKey,
    query,
  });

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (!data) {
    return null;
  }

  const { positions } = data.axes[0];
  const options = positions
    // A single hierarchy is expressed in this widget's query: each position contains a single member.
    .map(([member]) => ({
      value: quote(...member.namePath),
      label: member.captionPath[member.captionPath.length - 1],
    }));

  return (
    <div style={{ width: "100%" }}>
      <Select placeholder="Select one..." style={{ width: "99%", margin: 5 }}>
        {options.map(({ value, label }) => {
          return (
            <Select.Option value={value} key={value}>
              {label}
            </Select.Option>
          );
        })}
      </Select>
    </div>
  );
};
