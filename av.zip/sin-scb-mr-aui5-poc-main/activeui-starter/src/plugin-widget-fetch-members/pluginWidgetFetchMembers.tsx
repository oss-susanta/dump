import { WidgetPlugin } from "@activeviam/plugin-widget";

import { FetchMembers } from "./FetchMembers";
import { CellSetSelection } from "@activeviam/selection";
import { IconWorld } from "./IconWorld";

const widgetKey = "fetch-members";

const initialState = {
  widgetKey,
};

/**
 * {@link WidgetPlugin} displaying a Component to fetch members from certain coordinates.
 */
export const pluginWidgetFetchMembers: WidgetPlugin = {
  key: widgetKey,
  category: "misc",
  Component: FetchMembers,
  Icon: IconWorld,
  initialState,
  translations: {
    "en-US": {
      key: "Fetch Members",
      defaultName: "New Fetch Members",
    },
  },
};
