export { pluginWidgetPlotlyHeatmapChart } from "./pluginWidgetPlotlyHeatmapChart";
