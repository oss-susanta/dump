import {
  PlotlyWidgetState,
  WidgetWithQueryProps,
} from "@activeviam/activeui-sdk";
import useComponentSize from "@rehooks/component-size";
import { Spin } from "antd";
import { PlotSelectionEvent } from "plotly.js";
import React, {
  KeyboardEvent,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import Plot from "react-plotly.js";
import { getPlotlyChartValues } from "../utils";

export const PlotlyHeatmapChart = (
  props: WidgetWithQueryProps<PlotlyWidgetState>
): JSX.Element => {
  const container = useRef<HTMLDivElement>(null);
  const { height, width } = useComponentSize(container);
  const [selectedIndices, setSelectedIndices] = useState<
    number[] | undefined
  >();
  const { data, error, isLoading } = props.queryResult;
  const { onSelectionChange } = props;

  const handleSelectionChanged = (selection: PlotSelectionEvent) => {
    if (selection) {
      const indices = selection.points.map(({ pointIndex }) => pointIndex);
      setSelectedIndices(indices);
    }
  };

  const handleKeyUp = (event: KeyboardEvent) => {
    if (event.key === "Escape") {
      setSelectedIndices(undefined);
    }
  };

  // NOTE: To implement if required
  useEffect(() => {
    if (!data || !onSelectionChange) {
      return;
    }
    onSelectionChange(selectedIndices as any);
  }, [selectedIndices, onSelectionChange]);

  const plotlyChart = useMemo(() => {
    const title = undefined;
    const { x, y, z } = getPlotlyChartValues(data);

    return (
      <Plot
        data={[
          {
            type: "heatmap",
            x: x.values,
            y: y.values,
            z: z.values,
            ["hoverongaps" as any]: false,
            hovertemplate: "%{x}<br>%{y}<br>%{z}<extra></extra>",
            selectedpoints: selectedIndices,
          },
        ]}
        layout={{
          title,
          xaxis: {
            title: { text: x.title },
          },
          yaxis: {
            title: { text: y.title },
          },
          height,
          width: width - 15, // to give some space for modebar
          margin: {
            t: 30,
            pad: 2,
          },
        }}
        config={{ displaylogo: false, modeBarButtonsToRemove: [] }}
        onSelected={handleSelectionChanged}
      />
    );
  }, [data, width, height]);

  return (
    <div
      ref={container}
      style={{ ...props.style, height: "100%" }}
      tabIndex={0}
      onKeyUp={handleKeyUp}
    >
      {error ? (
        error.stackTrace
      ) : isLoading ? (
        <Spin />
      ) : data ? (
        plotlyChart
      ) : null}
    </div>
  );
};
