import {
  CellSetSelection,
  DataVisualizationContentEditor,
  DataVisualizationQueryEditor,
  FiltersEditor,
  PlotlyStyle,
  PlotlyWidgetState,
  WidgetAttributes,
  WidgetPlugin,
  withQueryResult,
} from "@activeviam/activeui-sdk";
import { IconHeatmapChart } from "./IconHeatmapChart";
import { PlotlyHeatmapChart } from "./PlotlyHeatmapChart";

const widgetKey = "plotly-heatmap-chart";

const attributes: WidgetAttributes = {
  xAxis: {
    role: "primaryOrdinal",
    isMainAxis: true,
    maxNumberOfFields: 1,
  },
  yAxis: {
    role: "secondaryOrdinal",
    maxNumberOfFields: 1,
  },
  values: {
    role: "primaryNumeric",
    maxNumberOfFields: 1,
  },
};

const initialState: PlotlyWidgetState = {
  widgetKey,
  query: {
    updateMode: "once",
  },
  mapping: {
    xAxis: [],
    yAxis: [],
    values: [],
  },
};

/**
 * Data visualization {@link WidgetPlugin} displaying a Plotly heatmap chart.
 */
export const pluginWidgetPlotlyHeatmapChart: WidgetPlugin<
  PlotlyWidgetState,
  CellSetSelection,
  PlotlyStyle
> = {
  attributes,
  category: "dataVisualization",
  subCategory: "line",
  Component: withQueryResult(PlotlyHeatmapChart),
  contentEditor: DataVisualizationContentEditor,
  queryEditor: DataVisualizationQueryEditor,
  filtersEditor: FiltersEditor,
  Icon: IconHeatmapChart,
  key: widgetKey,
  initialState,
  contextMenuItems: [],
  menuItems: [],
  titleBarButtons: [],
  translations: {
    "en-US": {
      key: "Heatmap chart",
      defaultName: "New heatmap chart",
    },
  },
};
