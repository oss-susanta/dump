import React from "react";
import { HeatMapOutlined } from "@ant-design/icons";

/**
 * Large icon of the heatmap chart, usable to represent in the widgets ribbon.
 */
export const IconHeatmapChart = () => (
  <HeatMapOutlined style={{ fontSize: "25px", marginBottom: "2px" }} />
);
