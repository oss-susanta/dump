<div align="center">
    <img src="standard-chartered.svg">
    <h1>ActiveUI5 PoC for MarketRisk Migration</h1>
</div>


- [📋 Summary](#-summary)
- [🙋 Contact](#-contact)
- [📝 Requirements](#-requirements)
  - [✅ Dashboard State Lifecycle hooks](#-dashboard-state-lifecycle-hooks)
  - [✅ Unique id for a widget in dashboard](#-unique-id-for-a-widget-in-dashboard)
  - [✅ [APACS-4183] How to create different types of filter](#-apacs-4183-how-to-create-different-types-of-filter)
  - [✅ [APACS-4175] How to get (Dim/Hier/Lvl) from (Row/Col/Filter/Measure) of a widget](#-apacs-4175-how-to-get-dimhierlvl-from-rowcolfiltermeasure-of-a-widget)
  - [✅ [APACS-4174] How to get (Dim/Hier/Lvl/member) from cell location of a widget](#-apacs-4174-how-to-get-dimhierlvlmember-from-cell-location-of-a-widget)
  - [✅ [APACS-4176] How to retrieve member values from the given (Server/Cube/Dim/Hir/Lvl)](#-apacs-4176-how-to-retrieve-member-values-from-the-given-servercubedimhirlvl)
  - [✅ [APACS-4173] New Plotly Charts](#-apacs-4173-new-plotly-charts)
  - [🔜 [APACS-4094] Fix Vulnerabilities from npm audit report](#-apacs-4094-fix-vulnerabilities-from-npm-audit-report)
- [🛠️ How to Run](#️-how-to-run)
- [📔 Extras](#-extras)
  - [💡 How to activate Redux DevTools](#-how-to-activate-redux-devtools)
  - [💡 How to activate advanced editors](#-how-to-activate-advanced-editors)

## 📋 Summary 
Demo project to help migration of MarketRisk to ActiveUI5

## 🙋 Contact
- Tin [`tht@activeviam.com`]

## 📝 Requirements
The requirements are coming from the list of JIRA tickets. See the umbrella ticket [APACS-4172](https://support.activeviam.com/jira/browse/APACS-4172)

### ✅ Dashboard State Lifecycle hooks
Dashboard state is located in Redux store. ActiveUI will use below actions to interact the dashboard state:
- `DashboardLoadedAction`
- `DashboardUnloadedAction`
- `DashboardUpdatedAction`
- `DashboardSavedAction`

We can use Redux middleware to intercept one of the above action.

See [customMiddleware.tsx](activeui-starter/src/store/customMiddleware.tsx) where we intercept `DashboardUpdatedAction` and find out if the page/widget get removed/added.

For further details, check out the official guide on [how to interact with ActiveUI state](https://activeviam.com/activeui/documentation/latest/docs/interact-with-the-state-of-activeui)

### ✅ Unique id for a widget in dashboard
See the `_uniqueWidgetKeys()` method in [handleWidgetChanges.tsx](activeui-starter/src/store/handleWidgetChanges.tsx)

### ✅ [APACS-4183] How to create different types of filter
Given the input dimension/hierarchy/member values and filter type, create different [types of filter](https://activeui.activeviam.com/activeui/documentation/latest/docs/api/types#filter) object and apply to current dashboard.

![Filter Menu Items](images/Filter%20Menu%20Items.png)

Open an existing dashbard. You will see a new menu such as `Filter->Filter on Members`. Once the user clicked, it will apply a filter for selected menu to all the widgets(or pages) in current dashboard.

For detail implementation:
- see [index.tsx](activeui-starter/src/menu/index.ts) which register a new menu
- see [FilterOnMembersMenuItem.tsx](activeui-starter/src/menu/filter/FilterOnMembersMenuItem.tsx), [FilterOnTopBottomMembersMenuItem.tsx](activeui-starter/src/menu/filter/FilterOnTopBottomMembersMenuItem.tsx) and [FilterOnLowerOrGreaterValueMenuItem.tsx](activeui-starter/src/menu/filter/FilterOnLowerOrGreaterValueMenuItem.tsx) where three different filter types are created
- see package `utils/filter/` which includes functions to create more filter types

### ✅ [APACS-4175] How to get (Dim/Hier/Lvl) from (Row/Col/Filter/Measure) of a widget
This is to show how to get coordinates(dimension, hierarchy, level) from the widgets.

![Get Coordinates Menu](images/Get%20coordinates%20Menu.png)

Open an existing dashbard. Find the menu `Get Coordinates` from one of the pivot table. Once the user clicked, it will logs the coordinates details in the console.

For detail implementation:
- see [pluginsMarketRisk.tsx](activeui-starter/src/pluginsMarketRisk.tsx) where we register a new menu item to the table based widgets. Note that you can register to other widgets as well.
- see [GetCoordinatesMenuItem.tsx](activeui-starter/src/plugin-menu-item-get-coordinates/GetCoordinatesMenuItem.tsx) for details on how to retrieve the coordinates from rows, columns, measures and filters.

### ✅ [APACS-4174] How to get (Dim/Hier/Lvl/member) from cell location of a widget
This is to show how to get cell locations (dimension, hierarchy, level) from the widgets.

Open an existing dashbard. Just select the cell(s) with value in one of the table widget. It will logs the cell value and location details in the console. To identify which one is considered as valid cell, see [canGetCellLocationOnSelection.ts](activeui-starter/src/plugin-selection-listener-get-cell-location/canGetCellLocationOnSelection.ts)

For detail implementation:
- see [pluginsMarketRisk.tsx](activeui-starter/src/pluginsMarketRisk.tsx) where we register a new selection listener to the table based widgets. Note that you can register to other widgets as well.
- see [SelectionListenerGetCellLocation.tsx](activeui-starter/src/plugin-selection-listener-get-cell-location/SelectionListenerGetCellLocation.tsx) for details on how to retrieve the current cell location details.

### ✅ [APACS-4176] How to retrieve member values from the given (Server/Cube/Dim/Hir/Lvl)
This is to show how to retrieve members from the given level coordinates.

![Fetch Members Widget](images/FetchMembers%20Widget.png)

Open a dashboard and select the `Fetch Members` widget from the widget bar. It will retrieve the members from the currency level.

See [FetchMembers.tsx](activeui-starter/src/plugin-widget-fetch-members/FetchMembers.tsx) for implementation details.

### ✅ [APACS-4173] New Plotly Charts
This is to show how to create ActiveUI widgets to support new Plotly charts which are not included in the SDK.
The new charts are added in the widget ribbon.

![Surface chart](images/SurfaceChart.png)
![Heatmap](images/Heatmap.png)

For implenmation details, see [3D surface chart](activeui-starter/src/plugin-widget-plotly-3Dsurface-chart/) and [heatmap chart](activeui-starter/src/plugin-widget-plotly-heatmap-chart/).

[getChartValues.ts](activeui-starter/src/utils/plotly/getChartValues.ts) is the critical part to transform the MDX result into Ploty data structure.
You can refer to the official documentation [MDX CellSet](https://activeviam.com/activepivot/latest/docs/mdx/mdx_cellset/) for details dexplanation.




### 🔜 [APACS-4094] Fix Vulnerabilities from npm audit report
> NOTICE: Release `5.1.0` by end of this year will resolve all the vulnerabilities. It will be breaking change and will not be backported to `5.0.x`.

Fix at least high/cirtical issue by upgrading them or using:
- [yarn resolutions](https://classic.yarnpkg.com/lang/en/docs/selective-version-resolutions/)
- [npm overrides](https://docs.npmjs.com/cli/v8/configuring-npm/package-json#overrides)

Let's try to fix each package and test to see if it breaks anything.


## 🛠️ How to Run
```bash
# Go to ActiveUI directory
cd activeui-starter/
# Install npm dependencies
yarn  
yarn start
# Go to http://localhost:3000
```


## 📔 Extras
### 💡 How to activate Redux DevTools
Redux devtools is very helpful to debug the redux store in the application.
- Install [this extension](https://chrome.google.com/webstore/detail/redux-devtools/lmhkpmbekcpmknklioeibfkpmmfibljd?hl=en) in the `Chrome`
- See [index.tsx](activeui-starter/src/index.tsx) where we register `devToolsEnhancerDevelopmentOnly()`
- Run `yarn start` and check the extension in `Chrome Developer Tools`

### 💡 How to activate advanced editors
To activate advanced editors such as MDX query eidtor and state editor, refer to [drawers/index.ts](activeui-starter/src/drawers/index.ts).