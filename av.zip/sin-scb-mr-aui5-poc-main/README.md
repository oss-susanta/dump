<div align="center">
    <img src="standard-chartered.svg">
    <h1>ActiveUI5 PoC for MarketRisk Migration</h1>
</div>


- [📋 Summary](#-summary)
- [🙋 Contact](#-contact)
- [📝 Requirements](#-requirements)
  - [✅ Dashboard State Lifecycle hooks](#-dashboard-state-lifecycle-hooks)
  - [✅ Unique id for a widget in dashboard](#-unique-id-for-a-widget-in-dashboard)
  - [✅ How to change a widget's state](#-how-to-change-a-widgets-state)
  - [⏳️ Fix Vulnerabilities from npm audit report](#️-fix-vulnerabilities-from-npm-audit-report)
- [🛠️ How to Run](#️-how-to-run)
- [📔 Extras](#-extras)
  - [💡 How to activate Redux DevTools](#-how-to-activate-redux-devtools)

## 📋 Summary 
Demo project to help migration of MarketRisk to ActiveUI5

## 🙋 Contact
- Tin [`tht@activeviam.com`]
- Joo [`jhs@activeviam.com`]

## 📝 Requirements
The requirements are coming from the list of JIRA tickets:
- [APACS-4118: lifecycle hooks required](https://support.activeviam.com/jira/browse/APACS-4118)
- [APACS-4094: security vulnerabilities in latest activeui 5](https://support.activeviam.com/jira/browse/APACS-4094)

### ✅ Dashboard State Lifecycle hooks
Dashboard state is located in Redux store. ActiveUI will use below actions to interact the dashboard state:
- `DashboardLoadedAction`
- `DashboardUnloadedAction`
- `DashboardUpdatedAction`
- `DashboardSavedAction`

We can use Redux middleware to intercept one of the above action.

See [customMiddleware.tsx](activeui-starter-source-5.0.13/src/store/customMiddleware.tsx) where we intercept `DashboardUpdatedAction` and find out if the page/widget get removed/added.

For further details, check out the official guide on [how to interact with ActiveUI state](https://activeviam.com/activeui/documentation/latest/docs/interact-with-the-state-of-activeui)

### ✅ Unique id for a widget in dashboard
See the `_uniqueWidgetKeys()` method in [handleWidgetChanges.tsx](activeui-starter-source-5.0.13/src/store/handleWidgetChanges.tsx)

### ✅ How to change a widget's state
This is to show how to change the state of widgets by applying filters.

Open an existing dashbard. You will see a new menu `Custom->Filter by USD`. Once the user clicked, it will apply a currency filter for `USD` to all the widgets(or pages) in current dashboard.

For detail implementation:
- see [index.tsx](activeui-starter-source-5.0.13/src/index.tsx) which register a new menu
- see [FilterByUSDMenuItem.tsx](activeui-starter-source-5.0.13/src/menu/FilterByUSDMenuItem.tsx) which create the currency filter in `MDX` and apply to the dashboard

### ⏳️ Fix Vulnerabilities from npm audit report
> TODO:

Fix at least high/cirtical issue by upgrading them or using:
- [yarn resolutions](https://classic.yarnpkg.com/lang/en/docs/selective-version-resolutions/)
- [npm overrides](https://docs.npmjs.com/cli/v8/configuring-npm/package-json#overrides)

Let's try to fix each package and test to see if it breaks anything.


## 🛠️ How to Run
```bash
# Go to ActiveUI directory
cd activeui-starter-source-5.0.13/
# Install npm dependencies
yarn  
yarn start
# Go to http://localhost:3000
```


## 📔 Extras
### 💡 How to activate Redux DevTools
Redux devtools is very helpful to debug the redux store in the application.
- Install [this extension](https://chrome.google.com/webstore/detail/redux-devtools/lmhkpmbekcpmknklioeibfkpmmfibljd?hl=en) in the `Chrome`
- See [index.tsx](activeui-starter-source-5.0.13/src/index.tsx) where we register `devToolsEnhancerDevelopmentOnly()`
- Run `yarn start` and check the extension in `Chrome Developer Tools`

