<div align="center">
    <img src="standard-chartered.svg">
    <h1>ActiveUI5 PoC for MarketRisk Migration</h1>
</div>


- [📋 Summary](#-summary)
- [🙋 Contact](#-contact)
- [📝 Requirements](#-requirements)
  - [✅ Dashboard State Lifecycle hooks](#-dashboard-state-lifecycle-hooks)
  - [✅ Unique id for a widget in dashboard](#-unique-id-for-a-widget-in-dashboard)
  - [✅ How to change a widget's state](#-how-to-change-a-widgets-state)
  - [✅ [APACS-4175] How to get (Dim/Hier/Lvl) from (Row/Col/Filter/Measure) of a widget](#-apacs-4175-how-to-get-dimhierlvl-from-rowcolfiltermeasure-of-a-widget)
  - [✅ [APACS-4174] How to get (Dim/Hier/Lvl/member) from cell location of a widget](#-apacs-4174-how-to-get-dimhierlvlmember-from-cell-location-of-a-widget)
  - [✅ [APACS-4176] How to retrieve member values from the given (Server/Cube/Dim/Hir/Lvl)](#-apacs-4176-how-to-retrieve-member-values-from-the-given-servercubedimhirlvl)
  - [⏳️ Fix Vulnerabilities from npm audit report](#️-fix-vulnerabilities-from-npm-audit-report)
- [🛠️ How to Run](#️-how-to-run)
- [📔 Extras](#-extras)
  - [💡 How to activate Redux DevTools](#-how-to-activate-redux-devtools)
  - [💡 How to activate advanced editors](#-how-to-activate-advanced-editors)

## 📋 Summary 
Demo project to help migration of MarketRisk to ActiveUI5

## 🙋 Contact
- Tin [`tht@activeviam.com`]

## 📝 Requirements
The requirements are coming from the list of JIRA tickets. See the umbrella ticket [APACS-4172](https://support.activeviam.com/jira/browse/APACS-4172)

### ✅ Dashboard State Lifecycle hooks
Dashboard state is located in Redux store. ActiveUI will use below actions to interact the dashboard state:
- `DashboardLoadedAction`
- `DashboardUnloadedAction`
- `DashboardUpdatedAction`
- `DashboardSavedAction`

We can use Redux middleware to intercept one of the above action.

See [customMiddleware.tsx](activeui-starter-source-5.0.13/src/store/customMiddleware.tsx) where we intercept `DashboardUpdatedAction` and find out if the page/widget get removed/added.

For further details, check out the official guide on [how to interact with ActiveUI state](https://activeviam.com/activeui/documentation/latest/docs/interact-with-the-state-of-activeui)

### ✅ Unique id for a widget in dashboard
See the `_uniqueWidgetKeys()` method in [handleWidgetChanges.tsx](activeui-starter-source-5.0.13/src/store/handleWidgetChanges.tsx)

### ✅ How to change a widget's state
This is to show how to change the state of widgets by applying filters.

![Filter by USD Menu](images/Filter%20by%20USD%20Menu.png)

Open an existing dashbard. You will see a new menu `Custom->Filter by USD`. Once the user clicked, it will apply a currency filter for `USD` to all the widgets(or pages) in current dashboard.

For detail implementation:
- see [index.tsx](activeui-starter-source-5.0.13/src/index.tsx) which register a new menu
- see [FilterByUSDMenuItem.tsx](activeui-starter-source-5.0.13/src/menu/FilterByUSDMenuItem.tsx) which create the currency filter in `MDX` and apply to the dashboard

### ✅ [APACS-4175] How to get (Dim/Hier/Lvl) from (Row/Col/Filter/Measure) of a widget
This is to show how to get coordinates(dimension, hierarchy, level) from the widgets.

![Get Coordinates Menu](images/Get%20coordinates%20Menu.png)

Open an existing dashbard. Find the menu `Get Coordinates` from one of the pivot table. Once the user clicked, it will logs the coordinates details in the console.

For detail implementation:
- see [pluginsMarketRisk.tsx](activeui-starter-source-5.0.13/src/pluginsMarketRisk.tsx) where we register a new menu item to the table based widgets. Note that you can register to other widgets as well.
- see [GetCoordinatesMenuItem.tsx](activeui-starter-source-5.0.13/src/plugin-menu-item-get-coordinates/GetCoordinatesMenuItem.tsx) for details on how to retrieve the coordinates from rows, columns, measures and filters.

### ✅ [APACS-4174] How to get (Dim/Hier/Lvl/member) from cell location of a widget
This is to show how to get cell locations (dimension, hierarchy, level) from the widgets.

![Get Cell Location Menu](images/Get%20cell%20location%20Menu.png)

Open an existing dashbard. Right click on one of the pivot table, select the menu `Get cell locations`. It will logs the cell value and location details in the console. Note that we disable the menu if the selected cell is not valid, such as empty cell, title cell, etc. You can customize it in [canGetCellLocationOnSelection.ts](activeui-starter-source-5.0.13/src/plugin-menu-item-get-cell-location/canGetCellLocationOnSelection.ts)

For detail implementation:
- see [pluginsMarketRisk.tsx](activeui-starter-source-5.0.13/src/pluginsMarketRisk.tsx) where we register a new menu item to the table based widgets. Note that you can register to other widgets as well.
- see [GetCoordinatesMenuItem.tsx](activeui-starter-source-5.0.13/src/plugin-menu-item-get-cell-location/GetCellLocationMenuItem.tsx) for details on how to retrieve the current cell location details.

### ✅ [APACS-4176] How to retrieve member values from the given (Server/Cube/Dim/Hir/Lvl)
This is to show how to retrieve members from the given level coordinates.

![Fetch Members Widget](images/FetchMembers%20Widget.png)

Open a dashboard and select the `Fetch Members` widget from the widget bar. It will retrieve the members from the currency level.

See [FetchMembers.tsx](activeui-starter-source-5.0.13/src/plugin-widget-fetch-members/FetchMembers.tsx) for implementation details.

### ⏳️ Fix Vulnerabilities from npm audit report
> TODO:

Fix at least high/cirtical issue by upgrading them or using:
- [yarn resolutions](https://classic.yarnpkg.com/lang/en/docs/selective-version-resolutions/)
- [npm overrides](https://docs.npmjs.com/cli/v8/configuring-npm/package-json#overrides)

Let's try to fix each package and test to see if it breaks anything.


## 🛠️ How to Run
```bash
# Go to ActiveUI directory
cd activeui-starter-source-5.0.13/
# Install npm dependencies
yarn  
yarn start
# Go to http://localhost:3000
```


## 📔 Extras
### 💡 How to activate Redux DevTools
Redux devtools is very helpful to debug the redux store in the application.
- Install [this extension](https://chrome.google.com/webstore/detail/redux-devtools/lmhkpmbekcpmknklioeibfkpmmfibljd?hl=en) in the `Chrome`
- See [index.tsx](activeui-starter-source-5.0.13/src/index.tsx) where we register `devToolsEnhancerDevelopmentOnly()`
- Run `yarn start` and check the extension in `Chrome Developer Tools`

### 💡 How to activate advanced editors
To activate advanced editors such as MDX query eidtor and state editor, refer to [drawers/index.ts](activeui-starter-source-5.0.13/src/drawers/index.ts).