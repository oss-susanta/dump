import fs from "fs";

const folders = fs.readdirSync("node_modules/@activeviam");
for (const folder of folders) {
  const pkg = `@activeviam/${folder}`;
  console.log(pkg);
}
