import fs from "fs";

const files = fs.readdirSync("vendor");
for (const file of files) {
  const microPkg = file
    .replace(/^activeviam-/, "")
    .replace(/-\d+.\d+.\d+.tgz$/, "");
  const pkg = `@activeviam/${microPkg}`;
  console.log(`"${pkg}": "file:vendor/${file}",`);
}
