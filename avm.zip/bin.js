#!/usr/bin/env node
require("./dist/cli/bin.js");
